import React, { Component } from 'react';
import Upload from './imageComponent';
import Popmain from './popmain';
import Sea from './searchdrop'
import Datepic from './Datepic'



class Review extends Component {
    componentWillMount() {
        const {steps} = this.props;
        console.log(steps);
    }
    render() {
        return (
            <div style={
                {width: '100%'}
            }>
                <h1>Your Data is Saved Succefully</h1>
            </div>
        );
    }
}

const STEPS = [
    {
        id: '1',
        message: 'Namaste, I am CyberDost! I am here to assist you regarding Cyber Crime Complaints',
        trigger: '2',
    },
    {
        id: '2',
        message: 'Please click the relevant option',
        trigger: 'optionsPop'
    },
    {
        id: 'optionsPop',
        message: 'Do you want to Register a complaint',
        trigger: 'ComplaintValue'
    },
    {
        id: 'ComplaintValue',
        options: [
            {
                value: 'yes',
                label: 'yes',
                trigger: 'SelectType',
                
            }, {
                value: 'no',
                label: 'No',
                trigger: 'Information'
            },
        ]
    },
    {
        id: 'SelectType',
        message: 'Select Type of Crime:',
        trigger: 'Category',
    },
    {
        id: 'Category',
        options: [
            {
                value: 'Child Sex Abuse/Rape/Obstacenity',
                label: 'Child Sex Abuse/Rape/Obstacenity',
                trigger: 'Non_Cyber'
            }, 
            {
                value: 'Cyber Crime',
                label: 'Cyber Crime',
                trigger: 'Cyber',
            },
        ]
    },
    {
        id: 'Non_Cyber',
        message: 'Select Type of Crime in Child Abuse',
        trigger: 'Category_1',
    },
    {
        id: 'Category_1',
        options: [
            {
                value: 'Child Pornography',
                label: 'Child Pornography',
                trigger: 'update',
            }, 
            {
                value: 'Rape/Gang Rape',
                label: 'Rape/Gang Rape',
                trigger: 'update',
            },
            {
                value: 'Sexual Obscenity',
                label: 'Sexual Obscenity',
                trigger: 'update',
            },
            {
                value: 'Sexually Explicit',
                label: 'Sexually Explicit',
                trigger: 'update',
            },
        ]
    },
    {
        id: 'Cyber',
        message: 'Select type of Crime in Cyber',
        trigger: 'Category_2',
    },
    {
        id: 'Category_2',
        options: [
            {
                value: 'Loss of Money',
                label: 'Loss of Money',
                trigger: 'Cat-21',
            },
            {
                value: 'Online Harassment',
                label: 'Online Harassment',
                trigger: 'Cat-22',
            },
            {
                value: 'Hacking',
                label: 'Hacking',
                trigger: 'Cat-23',
            },
            {
                value: 'Other online Crime',
                label: 'Other online Crime',
                trigger: 'Cat-24',
            },
        ]
    },
    {
        id: 'Cat-21',
        message: 'Select Category in Loss of Money',
        trigger: 'Loss_money',
    },
    {
        id: 'Loss_money',
        options: [
            {
                value: 'Banking/E-Wallet/Demat',
                label: 'Banking/E-Wallet/Demat',
                trigger: 'Cat-210',
            },
            {
                value: 'Job/Matrimonial,E-commerce,Fradulent SMS/Media Contenr/call',
                label: 'Job/Matrimonial,E-commerce,Fradulent SMS/Media Contenr/call',
                trigger: 'Cat-211',
            },
            {
                value: 'Email Fraud',
                label: 'Email Fraud',
                trigger: 'Cat-212',
            },
        ]
    },
    {
        id: 'Cat-210',
        message: 'Select how money lost in Banking:',
        trigger: 'Banking'
    },
    {
        id: 'Banking',
        options: [
            {
                value: 'Misuse of Credit/Debit Card/ATM Fraud',
                label: 'Misuse of Credit/Debit Card/ATM Fraud',
                trigger: 'update'
            },
            {
                value: 'Unauthorized Access Through Internet Banking',
                label: 'Unauthorized Access Through Internet Banking',
                trigger: 'update'
            },
            {
                value: 'Cryptocurrency/Bitcoin',
                label: 'Cryptocurrency/Bitcoin',
                trigger: 'update'
            },
            {
                value: 'E-Wallet Fraud,Demat/Mutual Fund',
                label: 'E-Wallet Fraud,Demat/Mutual Fund',
                trigger: 'update'
            },
        ]   
    },
    {
        id: 'Cat-211',
        message: 'Select how money lost in Online:',
        trigger: 'Online'
    },
    {
        id: 'Online',
        options: [
            {
                value: 'online Job Fraud',
                label: 'online Job Fraud',
                trigger: 'update'
            },
            {
                value: 'Online Matrimonial Fraud',
                label: 'Online Matrimonial Fraud',
                trigger: 'update'
            },
        ]
    },
    {
        id: 'Cat-212',
        message: 'Select how money lost in Email Fraud:',
        trigger: 'Email Fraud',
    },
    {
        id: 'Email Fraud',
        options: [
            {
                value: 'Spoof Email',
                label: 'Spoof Email',
                trigger: 'update'
            },
            {
                value: 'Business Email',
                label: 'Business Email',
                trigger: 'update'
            },
            {
                value: 'Compromise',
                label: 'Compromise',
                trigger: 'update'
            },
            {
                value: 'Email Hacking',
                label: 'Email Hacking',
                trigger: 'update'
            },
            {
                value: 'Threatening Email',
                label: 'Threatening Email',
                trigger: 'update'
            },
            {
                value: 'Phishing Email',
                label: 'Phishing Email',
                trigger: 'update'
            },
        ]
    },
    {
        id: 'Cat-22',
        message: 'Select Type in Online Harassment:',
        trigger: 'Online Harassment'
    },
    {
        id: 'Online Harassment',
        options: [
            {
                value: 'Receving Offensive Messages',
                label: 'Receving Offensive Messages',
                trigger: 'update'
            },
            {
                value: 'Online Bulying/Stalking',
                label: 'Online Bulying/Stalking',
                trigger: 'update'
            },
        ]
    },
    {
        id: 'Cat-23',
        message: 'Select type of Hacking:',
        trigger: 'Hacking',
    },
    {
        id: 'Hacking',
        options: [
            {
                value: 'Profile Hacking',
                label: 'Profile Hacking',
                trigger: 'Cat-230',
            },
            {
                value: 'Computer Hacking',
                label: 'Computer Hacking',
                trigger: 'Cat-231',
            },
        ]
    },
    {
        id: 'Cat-230',
        message: 'Select type of Hacking in Profile:',
        trigger: 'Profile_Hacking',
    },
    {
        id: 'Profile_Hacking',
        options: [
            {
                value: 'Identity Theft',
                label: 'Identity Theft',
                trigger: 'update'
            },
            {
                value: 'Fake Profile',
                label: 'Fake Profile',
                trigger: 'update'
            },
            {
                value: 'Cheating by Impersonation',
                label: 'Cheating by Impersonation',
                trigger: 'update'
            },
        ]
    },
    {
        id: 'Cat-231',
        message: 'Select type of Hacking in Computer',
        trigger: 'Computer',
    },
    {
        id: 'Computer',
        options: [
            {
                value: 'Damage to computer',
                label: 'Damage to computer',
                trigger: 'update'
            },
            {
                value: 'Data Breach',
                label: 'Data Breach',
                trigger: 'update'
            },
            {
                value: 'Altered Computer program',
                label: 'Altered Computer program',
                trigger: 'update'
            },
            {
                value: 'ransomware',
                label: 'ransomware',
                trigger: 'update'
            },
        ]
    },
    {
        id: 'Cat-24',
        message: 'Select other Online Crime:',
        trigger: 'Other',
    },
    {
        id: 'Other',
        options: [
            {
                value: 'Online Anti National/Communal Hatred/Terror Activity',
                label: 'Online Anti National/Communal Hatred/Terror Activityr',
                trigger: 'update'
            },
            {
                value: 'online prostitution/Human Trafficking',
                label: 'online prostitution/Human Trafficking',
                trigger: 'update'
            },
            {
                value: 'online Gambling',
                label: 'online Gambling',
                trigger: 'update'
            },
            {
                value: 'other',
                label: 'other',
                trigger: 'update'
            },
        ]
    },
    {
        id: 'update',
        message: 'Do you want to add any attachments',
        trigger: 'Attachments',
    },
    {
        id: 'Attachments',
        options: [
            {
                value: 'Yes',
                label: 'Yes',
                trigger: 'Upload'
            },
            {
                value: 'No',
                label: 'No',
                trigger: 'Location',
            },
        ],
    },
    {
        id: 'Upload',
        component: <Upload />,
        waitAction: true,
    },
    {
        id: 'Location',
        message: 'Do you want to give Location Details: ',
        trigger: 'Loc',
    },
    {
        id: 'Loc',
        options: [
            {
                value: 'Yes',
                label: 'Yes',
                trigger: 'Loc-Details',
            },
            {
                value: 'No',
                label: 'No',
                trigger: 'Information',
            },
        ],
    },
    {
        id: 'Loc-Details',
        component: <Popmain />,
        waitAction:true,
    },
    {
        id: 'Information',
        component: <Review />,
        end: true,
    }
]

export default STEPS;