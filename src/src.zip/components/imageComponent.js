import React from "react";
import "react-dropzone-uploader/dist/styles.css";
import { storage } from "./firebase";
import { useState } from "react";

const Upload = (props) => {
  const [files, setFiles] = useState([]);
  const [num, setNum] = useState([]);
  const [status, setStatus] = useState("");
  const [disabled, setDisbled] = useState(false);
  var urls = [];

  const onFileChange = (e) => {
    for (let i = 0; i < e.target.files.length; i++) {
      const newFile = e.target.files[i];
      setFiles((prevState) => [...prevState, newFile]);
      setNum((prev) => [...prev, 0]);
      setStatus((p) => "");
    }
  };

  const onUploadSubmission = (e) => {
    e.preventDefault();
    if (files.length !== 0) {
      setStatus((prev) => "uploading ..");
      const promises = [];
      files.forEach((file, ind) => {
        const uploadTask = storage
          .ref()
          .child(`images/${file.name}`)
          .put(file);
        promises.push(uploadTask);
        uploadTask.on(
          "state_changed",
          (snapShot) => {
            console.log(snapShot);
            if (snapShot.bytesTransferred === snapShot.totalBytes) {
              setNum((prev) => {
                var lst = prev;
                lst[ind] = 1;
                return lst;
              });
            }
          },
          (err) => {
            setNum((prev) => {
              var lst = prev;
              lst[ind] = -1;
              return lst;
            });
          }
          // () => {
          //   storage
          //     .ref("images")
          //     .child(file.name)
          //     .getDownloadURL()
          //     .then((fireBaseUrl) => {
          //       urls.push(fireBaseUrl);
          //       console.log(urls);
          //     });
          // }
        );
      });

      Promise.all(promises)
        .then(() => {
          files.forEach((file, i) => {
            storage
              .ref("images")
              .child(file.name)
              .getDownloadURL()
              .then((fireBaseUrl) => {
                urls.push(fireBaseUrl);
                if (i === files.length-1) {
                  setStatus((prev) => "uploaded!");
                  setDisbled((prev) => !prev);
                  props.triggerNextStep({ trigger: "Location", value: urls });
                }
              });
          });
        })
        .catch((err) => {
          console.log(err.code);
          setStatus((prev) => "Some problem occured!");
          console.log("err2");
        });
    } else {
      setStatus("No files selected!");
    }
  };

  return (
    <div>
      <form onSubmit={onUploadSubmission}>
        <div
          style={{
            width: "100%",
            display: "flex",
            flexDirection: "row",
            justifyContent: "space-around",
          }}
        >
          <input
            disabled={disabled}
            type="file"
            className="button1"
            multiple
            onChange={onFileChange}
          ></input>
          <div style={{ width: "2vw" }} />
          <button className="button1" disabled={disabled}>
            UPLOAD
          </button>
        </div>
      </form>
      <div style={{ height: "10px" }} />
      <div
        style={{
          display: "flex",
          width: "100%",
          justifyContent: "center",
          flexDirection: "column",
        }}
      >
        {files.map((f, ind) =>
          num[ind] === 0 ? (
            <li style={{ color: "black" }} id={f.name}>
              {f.name}
            </li>
          ) : num[ind] === 1 ? (
            <li style={{ color: "green" }} id={f.name}>
              {f.name}
            </li>
          ) : (
            <li style={{ color: "red" }} id={f.name}>
              {f.name}
            </li>
          )
        )}
      </div>
      <div style={{ display: "flex", width: "100%", justifyContent: "center" }}>
        <label style={{ margin: "10px" }}>{status}</label>
      </div>
    </div>
  );
};

export default Upload;
