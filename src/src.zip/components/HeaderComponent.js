import React, {Component} from 'react';
import 'font-awesome/css/font-awesome.min.css';
class Header extends Component{
    render(){
        return(
            <div>
                <i className="fa fa-refresh">no spinner but why</i>
            </div>
        );
    }
}

export default Header;