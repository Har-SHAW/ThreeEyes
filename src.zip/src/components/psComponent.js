const PS_In = [
  {
    id: "BADDA",
    value: "BADDA",
  },
  {
    id: "AERODROME",
    value: "AERODROME",
  },
  {
    id: "ANNPURNA",
    value: "ANNPURNA",
  },
  {
    id: "PANDRINATH",
    value: "PANDRINATH",
  },
  {
    id: "BETMA",
    value: "BETMA",
  },
  {
    id: "BANGANGA",
    value: "BANGANGA",
  },
  {
    id: "BHAWARKUWA",
    value: "BHAWARKUWA",
  },
  {
    id: "KOTWALI CENTRAL INDORE",
    value: "KOTWALI CENTRAL INDORE",
  },
  {
    id: "CHHATRIPURA",
    value: "CHHATRIPURA",
  },
  {
    id: "CHHOTI GWAL TOLI",
    value: "CHHOTI GWAL TOLI",
  },
  {
    id: "CHANDAN NAGAR",
    value: "CHANDAN NAGAR",
  },
  {
    id: "DEPALPUR",
    value: "DEPALPUR",
  },
  {
    id: "UTAMPURA",
    value: "UTAMPURA",
  },
  {
    id: "HATOD",
    value: "HATOD",
  },
  {
    id: "HIRA NAGAR",
    value: "HIRA NAGAR",
  },
  {
    id: "JUNI INDORE",
    value: "JUNI INDORE",
  },
  {
    id: "AJK INDORE",
    value: "AJK INDORE",
  },
  {
    id: "KHAJRANA",
    value: "KHAJRANA",
  },
  {
    id: "KHUDEL",
    value: "KHUDEL",
  },
  {
    id: "KSHIPRA",
    value: "KSHIPRA",
  },
  {
    id: "KISHAN PURA/GANJ",
    value: "KISHAN PURA/GANJ",
  },
  {
    id: "LASUDIYA",
    value: "LASUDIYA",
  },
  {
    id: "MAHILA THANA INDORE",
    value: "MAHILA THANA INDORE",
  },
  {
    id: "MAHATMA GANDHI ROAD",
    value: "MAHATMA GANDHI ROAD",
  },
  {
    id: "MALHARGANJ",
    value: "MALHARGANJ",
  },
  {
    id: "MANPUR",
    value: "MANPUR",
  },
  {
    id: "MHOW",
    value: "MHOW",
  },
  {
    id: "MIG COLONY",
    value: "MIG COLONY",
  },
  {
    id: "PALASIA",
    value: "PALASIA",
  },
  {
    id: "PARDESIPURA",
    value: "PARDESIPURA",
  },
  {
    id: "RAJENDRA NAGAR",
    value: "RAJENDRA NAGAR",
  },
  {
    id: "RAUJI  BAZAR",
    value: "RAUJI  BAZAR",
  },
  {
    id: "SADAR BAZAR",
    value: "SADAR BAZAR",
  },
  {
    id: "SANYOGITAGANJ",
    value: "SANYOGITAGANJ",
  },
  {
    id: "SARAFA",
    value: "SARAFA",
  },
  {
    id: "SANWER",
    value: "SANWER",
  },
  {
    id: "SIMROL",
    value: "SIMROL",
  },
  {
    id: "TUKOGANJ",
    value: "TUKOGANJ",
  },
  {
    id: "VIJAY NAGAR",
    value: "VIJAY NAGAR",
  },
  {
    id: "AZAD NAGAR",
    value: "AZAD NAGAR",
  },
  {
    id: "KANADIYA",
    value: "KANADIYA",
  },
  {
    id: "TEJAJI NAGAR",
    value: "TEJAJI NAGAR",
  },
  {
    id: "CRIME BRANCH",
    value: "CRIME BRANCH",
  },
  {
    id: "DWARKAPURI",
    value: "DWARKAPURI",
  },
  {
    id: "RAAU",
    value: "RAAU",
  },
  {
    id: "PS Traffic Indore",
    value: "PS Traffic Indore",
  },
  {
    id: "CHANDRAVATI GANJ",
    value: "CHANDRAVATI GANJ",
  },
  {
    id: "GANDHI NAGAR",
    value: "GANDHI NAGAR",
  },
  {
    id: "TILAK NAGAR",
    value: "TILAK NAGAR",
  },
];

export default PS_In;
