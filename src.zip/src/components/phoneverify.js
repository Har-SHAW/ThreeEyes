import React, { Component } from "react";
import { firebase } from "./firebase";

class PhoneVerify extends Component {
  state = {
    number: "",
    disabled: false,
    isCodeAvailable: false,
    OTP: "",
  };

  componentDidMount() {
    window.recaptchaVerifier = new firebase.auth.RecaptchaVerifier(
      "recaptcha-container",
      {
        size: "invisible",
      }
    );
  }

  onChange = (number) => this.setState({ number });

  onOtpChange = (OTP) => this.setState({ OTP });

  PhoneNumberVerify(number) {
    firebase.auth().settings.appVerificationDisabledForTesting = true;
    const appVerifier = window.recaptchaVerifier;
    firebase
      .auth()
      .signInWithPhoneNumber("+91" + number, appVerifier)
      .then((confirmationResult) => {
        console.log("success", confirmationResult);
        this.setState({
          verificationId: confirmationResult.verificationId,
          isCodeAvailable: true,
        });
        window.confirmationResult = confirmationResult;
      })
      .catch((error) => {
        console.log("err", error);
      });
  }

  OTPverify(code) {
    // var credential = firebase.auth.PhoneAuthProvider.credential(this.state.verificationId, code)
    // firebase.auth().signInWithCredential(credential)
    //   .then((user) => {
    //     console.log(user);
    //   })
    //   .catch((err) => {
    //     console.log(err);
    //   });
    console.log(code);
    window.confirmationResult
      .confirm(code)
      .then(function(result) {
        var user = result.user;
        console.log(user);
      })
      .catch(function(error) {
        console.log(error);
      });
  }
  render() {
    return (
      <div>
        <div
          style={{
            width: "100%",
            display: "flex",
            flexDirection: "row",
            justifyContent: "space-around",
          }}
        >
          <input
            id="Phone Number"
            type="text"
            onChange={(e) => this.onChange(e.target.value)}
          ></input>
          <button
            id="recaptcha-container"
            className="button1"
            onClick={() => this.PhoneNumberVerify(this.state.number)}
          >
            Send OTP
          </button>
        </div>
        <div style={{ height: "10px" }} />
        {this.state.isCodeAvailable ? (
          <div
            style={{
              width: "100%",
              display: "flex",
              flexDirection: "row",
              justifyContent: "space-around",
            }}
          >
            <input
              id="Code"
              type="text"
              onChange={(e) => this.onOtpChange(e.target.value)}
            ></input>
            <button
              className="button1"
              onClick={() => this.OTPverify(this.state.OTP)}
            >
              Verify OTP
            </button>
          </div>
        ) : null}
      </div>
    );
  }
}

export default PhoneVerify;
