const options = [
    {
        label:'Email',
        value: 'Email',
    },
    {
        label: 'FaceBook',
        value:'FaceBook',
    },
    {
        label: 'WhatsApp',
        value:'WhatsApp',
    },
    {
        label: 'Hike',
        value:'Hike',
    },
    {
        label: 'Instagram',
        value:'Instagram',
    },
    {
        label: 'SnapChat',
        value:'SnapChat',
    },
    {
        label: 'Tik Tok',
        value:'Tik Tok',
    },
    {
        label: 'Twitter',
        value:'Twitter',
    },
    {
        label: 'WebSite URL',
        value:'WebSite URL',
    },
    {
        label: 'WeChat',
        value:'WeChat',
    },
    {
        label: 'Youtube',
        value:'Youtube',
    },
    {
        label: 'LinkedIn',
        value:'LinkedIn',
    },
    {
        label: 'Telegram',
        value:'Telegram',
    },
    {
        label: 'Other',
        value:'Other',
    },
]

export default options;
