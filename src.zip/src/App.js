import React, { Component } from "react";
import "./App.css";
import Main from "./components/MainComponent";
import PhoneVerify from './components/phoneverify'

class App extends Component {
  render() {
    return (
      <div>
        <Main />
        <PhoneVerify/>
      </div>
    );
  }
}

export default App;
